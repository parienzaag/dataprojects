## 1. Geographic Data ##

import pandas as pd

airlines = pd.read_csv("airlines.csv")
airports = pd.read_csv("airports.csv")
routes = pd.read_csv("routes.csv")

#returning first row in each data frame
print(airlines.iloc[0])
print(airports.iloc[0])
print(routes.iloc[0])



## 4. Workflow With Basemap ##

import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap
m = Basemap(projection = 'merc', llcrnrlat= -80, urcrnrlat=80,llcrnrlon=-180,urcrnrlon=180)

## 5. Converting From Spherical to Cartesian Coordinates ##

m = Basemap(projection='merc', llcrnrlat=-80, urcrnrlat=80, llcrnrlon=-180, urcrnrlon=180)

x = airports['longitude'].tolist()
y = airports['latitude'].tolist()

x,y = m(x,y)



## 6. Generating A Scatter Plot ##

m = Basemap(projection='merc', llcrnrlat=-80, urcrnrlat=80, llcrnrlon=-180, urcrnrlon=180)
x, y = m(longitudes,latitudes)
#making a scatter plot on Basemap

m.scatter(x,y, s=1)

plt.show()

## 7. Customizing The Plot Using Basemap ##

m = Basemap(projection='merc', llcrnrlat=-80, urcrnrlat=80, llcrnrlon=-180, urcrnrlon=180)
longitudes = airports["longitude"].tolist()
latitudes = airports["latitude"].tolist()
x, y = m(longitudes, latitudes)
m.scatter(x, y, s=1)
#adding coastlines to map
m.drawcoastlines()
plt.show()

## 8. Customizing The Plot Using Matplotlib ##

# Add code here, before creating the Basemap instance.
#bc matplotlib runs under the hood can use those parameters

fig,ax = plt.subplots(figsize=(15,20))
ax.set_title('Scaled Up Earth with Coastlines')

m = Basemap(projection='merc', llcrnrlat=-80, urcrnrlat=80, llcrnrlon=-180, urcrnrlon=180)
longitudes = airports["longitude"].tolist()
latitudes = airports["latitude"].tolist()
x, y = m(longitudes, latitudes)
m.scatter(x, y, s=1)
m.drawcoastlines()
plt.show()

## 9. Introduction to Great Circles ##

#reading into a DF a csv with combined routes and longitude and latitude
geo_routes = pd.read_csv('geo_routes.csv')
#getting info to see if there are any null values
print(geo_routes.info())
#displaying the first 5 rows
print(geo_routes.head(5))

## 10. Displaying Great Circles ##

fig, ax = plt.subplots(figsize=(15,20))
m = Basemap(projection='merc', llcrnrlat=-80, urcrnrlat=80, llcrnrlon=-180, urcrnrlon=180)
m.drawcoastlines()

def create_great_circles(df):
    #going to use itterows to iterate over a df, then we need the index and row to do so.
    for index,row in df.iterrows():
        #assigning variables corresponding to each row value
        end_lat, start_lat = row['end_lat'], row['start_lat']
        end_lon, start_lon = row['end_lon'], row['start_lon']
        
        #need to have a conditioned statement to filter out the lat and lons that can be used to draw a great circle
        if abs(end_lat - start_lat)<180:
            #nested if statements
            if abs(end_lon - start_lon)<180:
                m.drawgreatcircle(start_lon,start_lat,end_lon, end_lat)
#creating a filtered dataframe to choose onliy where source is = to DFW
dfw = geo_routes[geo_routes['source'] == 'DFW']

create_great_circles(dfw)
plt.show()