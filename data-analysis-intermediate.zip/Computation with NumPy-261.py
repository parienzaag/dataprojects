## 2. Array Comparisons ##

import numpy as np
countries_canada =(world_alcohol[:,2]== "Canada")
#Extracted the 3rd column looking to see if Canada exists in the col.
years_1984 = (world_alcohol[:,0] == "1984")
#same as above

## 3. Selecting Elements ##

import numpy as np
country_is_algeria = (world_alcohol[:,2] == "Algeria")
country_algeria = (world_alcohol[country_is_algeria, :])


## 4. Comparisons with Multiple Conditions ##

import numpy as np
is_algeria_and_1986 = (world_alcohol[:,0] == "1986") & (world_alcohol[:,2] =="Algeria")

rows_with_algeria_and_1986 = world_alcohol[is_algeria_and_1986, :]


## 5. Replacing Values ##

import numpy as np
#indexing through matrix
str_2014 = (world_alcohol[:,0] == "1986")
#replacing all instances containing 1986 with 2014
world_alcohol[str_2014,0] = "2014"
#replacing all "Wine" with Grog
winer = world_alcohol[:,3] == "Wine"
world_alcohol[winer,3] = "Grog"


## 6. Replacing Empty Strings ##

import numpy as np
#finding all empty strings in 5th col

is_value_empty = world_alcohol[:,4] == ''
#replacing empty string
world_alcohol[is_value_empty,4] = '0'

## 7. Converting Data Types ##

import numpy as np

#extracting 5th col, avg amt of liters drunk
alcohol_consumption = world_alcohol[:,4]
#converting to float using astype()

alcohol_consumption.astype(float)

## 8. Computing with NumPy ##

import numpy as np
#assigning sum of alcohol consumption
total_alcohol = alcohol_consumption.sum(axis = 0)
#mean of consumption
average_alcohol = alcohol_consumption.mean(axis = 0)


## 9. Total Annual Alcohol Consumption ##

import numpy as np

is_canada_1986 = (world_alcohol[:,0] == "1986")&(world_alcohol[:,2] == "Canada")
#keeping only those with Canada and 1986
canada_1986 = world_alcohol[is_canada_1986,:]
canada_alcohol = canada_1986[:,4] 
str_empty = canada_alcohol== ''
canada_alcohol[str_empty] = "0"

canada_alcohol = canada_alcohol.astype(float)

total_canadian_drinking = canada_alcohol.sum()


## 10. Calculating Consumption for Each Country ##

import numpy as np
totals = {}
year_0 = world_alcohol[:,0] == "1989"
#keep only vector with '1989'
year = world_alcohol[year_0, :]

for country in countries:
    those_consumption = (year[:,2] == country)
    country_consumption = year[those_consumption,:]
    #extracting 5th column and replace '' with 0
    alcohol_column = country_consumption[:,4] 
    fifth_d = alcohol_column == ''
    alcohol_column[fifth_d] = '0'
    
    #conversion from string to float
    country_consumption = alcohol_column.astype(float)
    #summing the columns
    totals[country] = country_consumption.sum()
    
print(totals)


## 11. Finding the Country that Drinks the Most ##

highest_value = 0
highest_key = None
#finding country with highest value
#find the key assoc. w the highest value
for key in totals:
    #loop through the keys and values comparing each one to another
    #assign a variable to the key
    consumption = totals[key]
    #compare highest value with variable
    if highest_value < consumption:
        highest_value = consumption
        highest_key = key
        