## 2. Introduction ##

import pandas as pd
#reading a csv file into a pandas dataframe
titanic_survival = pd.read_csv("titanic_survival.csv")


## 3. Finding the Missing Data ##

#titanic_survival is now a pandas dataframe

age = titanic_survival["age"]
print(age.loc[10:20])
#finding the elements that are null
age_is_null = pd.isnull(age)
age_null_true = age[age_is_null]

age_null_count = len(age_null_true)
print (age_null_count)

## 4. Whats the big deal with missing data? ##

age_is_null = pd.isnull(titanic_survival["age"])
age_is_not_null = titanic_survival["age"][age_is_null == False]
correct_mean_age = sum(age_is_not_null)/len(age_is_not_null)

## 5. Easier Ways to Do Math ##

correct_mean_age = titanic_survival["age"].mean()
#using the above example to find the mean of  fare

correct_mean_fare = titanic_survival["fare"].mean()



## 6. Calculating Summary Statistics ##

passenger_classes = [1, 2, 3]
fares_by_class = {}

for aclass in passenger_classes:
    pclass_rows = titanic_survival[titanic_survival["pclass"] == aclass]
    #finding just the fares of the series by subsetting fares column
    pclass_fares = pclass_rows["fare"]
    fares_mean = pclass_fares.mean()
    fares_by_class[aclass] = fares_mean

## 7. Making Pivot Tables ##

import numpy as np
passenger_survival = titanic_survival.pivot_table(index="pclass", values="survived")
#index is column to group by, values is column to apply calculation, aggfunc is the specified function(from np library)

#ex to find the mean age of passengers
passenger_age = titanic_survival.pivot_table(index = "pclass", values ="age", aggfunc = np.mean)

print(passenger_age)

## 8. More Complex Pivot Tables ##

import numpy as np
columns = ["fare", "survived"]
#using the pivot table on multiple columns must be in a list format
port_stats = titanic_survival.pivot_table(index = "embarked", values = columns, aggfunc = np.sum)

print(port_stats)


## 9. Drop Missing Values ##

drop_na_rows = titanic_survival.dropna(axis=0)
#axis value = 1 drops columns that have null value
drop_na_columns = titanic_survival.dropna(axis=1)

#to drop multiple rows, use a specified list under axis
#to specify which columns to drop rows from subset is used
new_titanic_survival = titanic_survival.dropna(axis = 0, subset = ["age", "sex"])

print(new_titanic_survival)


## 10. Using iloc to Access Rows by Position ##

# We have already sorted new_titanic_survival by age
first_five_rows = new_titanic_survival.iloc[0:5]

#first ten rows
first_ten_rows = new_titanic_survival.iloc[0:10]
#assigning 5th row
row_position_fifth = new_titanic_survival.iloc[4]
#row with index label 25
row_index_25 = new_titanic_survival.loc[25]

## 11. Using Column Indexes ##

first_row_first_column = new_titanic_survival.iloc[0,0]
all_rows_first_three_columns = new_titanic_survival.iloc[:,0:3]
row_index_83_age = new_titanic_survival.loc[83,"age"]
row_index_766_pclass = new_titanic_survival.loc[766,"pclass"]

#use loc for index label 1100 on age col
row_index_1100_age = new_titanic_survival.loc[1100,"age"]

#assign val for row index 25 on survived col
row_index_25_survived = new_titanic_survival.loc[25,"survived"]
#assigning first 5 rows and 3 cols using iloc

five_rows_three_cols = new_titanic_survival.iloc[0:5, 0:3]


## 12. Reindexing Rows ##

#reindexing the datafram new_titanic_survival
titanic_reindexed = new_titanic_survival.reset_index(drop = True)

print(titanic_reindexed.iloc[0:5,0:3])

## 13. Apply Functions Over a DataFrame ##

def hundredth_row(column):
    hundredth_item = column.iloc[99]
    return hundredth_item

hundredth_row_var = titanic_survival.apply(hundredth_row)
def null_elements(series):
    null_series = pd.isnull(series)
    null = series[null_series]
    return len(null)

column_null_count = titanic_survival.apply(null_elements)


## 14. Applying a Function to a Row ##

def is_minor(row):
    if row["age"] < 18:
        return True
    else:
        return False

minors = titanic_survival.apply(is_minor, axis=1)
import pandas as pd
def of_age(row):
    if pd.isnull(row["age"]):
        return "unknown"
    elif row["age"] < 18:
        return "minor"
    else:
        return "adult"
    
age_labels = titanic_survival.apply(of_age, axis = 1)




## 15. Calculating Survival Percentage by Age Group ##

import pandas as pd
import numpy as np
age_group_survival = titanic_survival.pivot_table(index = "age_labels", values = "survived", aggfunc = np.mean)