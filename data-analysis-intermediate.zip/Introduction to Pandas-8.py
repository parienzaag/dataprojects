## 3. Read in a CSV file ##

import pandas as pd
#reading a csv file into a pandas dataset
food_info = pd.read_csv("food_info.csv")

print(type(food_info))

## 4. Exploring the DataFrame ##

print(food_info.head(3))
dimensions = food_info.shape
print(dimensions)
num_rows = dimensions[0]
print(num_rows)
num_cols = dimensions[1]
print(num_cols)

import pandas as pd
#first twenty rows using header() attribute
first_twenty = food_info.head(20)

## 7. Selecting a row ##

hundredth_row = food_info.loc[99]
print(hundredth_row)

## 8. Data types ##

import pandas as pd

print(food_info.dtypes)

## 9. Selecting multiple rows ##

print("Rows 3, 4, 5 and 6")
print(food_info.loc[3:6])

print("Rows 2, 5, and 10")
two_five_ten = [2,5,10]
print(food_info.loc[two_five_ten])

#finding number of rows
num_rows = food_info.shape[0]

last_rows = food_info.loc[num_rows-5: num_rows-1]

## 10. Selecting individual columns ##

# Series object.
ndb_col = food_info["NDB_No"]
print(ndb_col)

# Display the type of the column to confirm it's a Series object.
print(type(ndb_col))

#assigned column to variable
saturated_fat = food_info["FA_Sat_(g)"]
cholesterol = food_info["Cholestrl_(mg)"]


## 11. Selecting multiple columns by name ##

zinc_copper = food_info[["Zinc_(mg)", "Copper_(mg)"]]

columns = ["Zinc_(mg)", "Copper_(mg)"]
zinc_copper = food_info[columns]
#returned dataframe matches the order of the input list
elements = ['Selenium_(mcg)','Thiamin_(mg)']

selenium_thiamin = food_info[elements]




## 12. Practice ##

print(food_info.columns)#list of the column names
print(food_info.head(2))
#first get all names of columns (found in header) and convert to list
column_list = food_info.columns.tolist()
#now names are in list format and can loop through for the character "(g)" which each name has at ending 
gram_columns = []
for name in column_list:
    if name.endswith("(g)"):
    #returns True if conditions are true
        gram_columns.append(name)
    #building a list
#building the dataframw with only names that have "(g)" at end
gram_df = food_info[gram_columns]
print(gram_df.head(3))