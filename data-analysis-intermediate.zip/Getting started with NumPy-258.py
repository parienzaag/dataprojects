## 2. Creating arrays ##

import numpy as np
vector = np.array([10,20,30])
matrix = np.array([[5,10,15],[20,25,30],[35,40,45]])



## 3. Array shape ##

vector = np.array([10, 20, 30])
matrix = np.array([[5, 10, 15], [20, 25, 30], [35, 40, 45]])
vector_shape = np.shape(vector)
matrix_shape = np.shape(matrix)

print(vector_shape)
print (matrix_shape)

## 4. Using NumPy ##

import numpy as np
#make sure to import numpy
world_alcohol = np.genfromtxt("world_alcohol.csv", delimiter = ",")
#taking out the comma to make this list of list array
print (type(world_alcohol))

## 5. Data types ##

#value in ndarray must have same data type, lists can have different data types
#Numpy has data types different from py.
import numpy as np
#dtype will display data types in the array
world_alcohol_dtype = world_alcohol.dtype

print(world_alcohol_dtype)

## 7. Reading in the data correctly ##

import numpy as np
world_alcohol = np.genfromtxt("world_alcohol.csv", delimiter = ",", dtype = "U75", skip_header = 1)

print (world_alcohol)

## 8. Indexing arrays ##

import numpy as np

uruguay_other_1986 = world_alcohol [1,4]

third_country = world_alcohol[2,2]

## 9. Slicing arrays ##

import numpy as np
countries = world_alcohol[:,2]
alcohol_consumption = world_alcohol[:,4]

# colon(:) selects all dimensions in array,then the second position is index.
#Ex of 1 Dimension & element from other. (selection, column index)

## 10. Slicing one dimension ##

#Select whole Dimension and Slice another
import numpy as np
#select all rows, first 2 columns
first_two_columns = world_alcohol[:,0:2]
first_ten_years = world_alcohol[0:10, 0]
first_ten_rows = world_alcohol[0:10, :]


## 11. Slicing arrays ##

# the number following the colon is always the row that is excluded, number prior to colon is always included. Remember row count begins at 0

import numpy as np
first_twenty_regions = world_alcohol[0:20, 1:3]
#world_alcohol is in ndarray format
