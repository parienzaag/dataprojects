## 1. Overview ##

import pandas as pd
food_info = pd.read_csv("food_info.csv")
#dataframe made as obj food_info
col_names = food_info.columns.tolist()
#taking column names and putting into a list
print(col_names)
print(food_info.head(3))

## 2. Transforming a Column ##

div_1000 = food_info["Iron_(mg)"] / 1000
add_100 = food_info["Iron_(mg)"] + 100
sub_100 = food_info["Iron_(mg)"] - 100
mult_2 = food_info["Iron_(mg)"]*2

sodium_grams = food_info["Sodium_(mg)"]/1000
sugar_milligrams = food_info["Sugar_Tot_(g)"]*1000

## 3. Performing Math with Multiple Columns ##

water_energy = food_info["Water_(g)"] * food_info["Energ_Kcal"]
print(water_energy[0:5])

grams_of_protein_per_gram_of_water = food_info["Protein_(g)"]/food_info["Water_(g)"]

milligrams_of_calcium_and_iron = food_info["Calcium_(mg)"] + food_info["Iron_(mg)"]

## 4. Create a Nutritional Index ##

weighted_protein = food_info["Protein_(g)"] * 2 

#multiplying lipid by .75
weighted_fat = food_info["Lipid_Tot_(g)"] *(-0.75)

#adding the variables together
# Score = 2*(Protein) -0.75(Lipid)
initial_rating = weighted_protein + weighted_fat

## 5. Normalizing Columns in a Data Set ##

print(food_info["Protein_(g)"][0:5])
max_protein = food_info["Protein_(g)"].max()
min_protein = food_info["Protein_(g)"].min()
x = food_info["Protein_(g)"]
#frmla for normalized x-min(x)/(max(x) - min(x))
normalized_protein = (x - min_protein)/((max_protein - min_protein))

#normalizing fats
max_fat = food_info["Lipid_Tot_(g)"].max()
min_fat = food_info["Lipid_Tot_(g)"].min()
l = food_info["Lipid_Tot_(g)"]

normalized_fat = (l - min_fat)/((max_fat - min_fat))

## 6. Creating a New Column ##

normalized_protein = (food_info["Protein_(g)"] - food_info["Protein_(g)"].min()) / (food_info["Protein_(g)"].max() - food_info["Protein_(g)"].min())
normalized_fat = (food_info["Lipid_Tot_(g)"] - food_info["Lipid_Tot_(g)"].min()) / (food_info["Lipid_Tot_(g)"].max() - food_info["Lipid_Tot_(g)"].min())

#Assign new column to series
food_info["Normalized_Protein"] = normalized_protein

food_info["Normalized_Fat"] = normalized_fat
#now the columns in food_info series have been replaced with the value of variables


## 7. Create a Normalized Nutritional Index ##

food_info["Normalized_Protein"] = normalized_protein
food_info["Normalized_Fat"] = normalized_fat

food_info["Norm_Nutr_Index"] = food_info["Normalized_Protein"]*2 + (-.75*food_info["Normalized_Fat"])

## 8. Sorting a DataFrame by a Column ##

food_info["Norm_Nutr_Index"] = 2*food_info["Normalized_Protein"] + (-0.75*food_info["Normalized_Fat"])


food_info.sort_values("Norm_Nutr_Index", inplace = True, ascending = False)