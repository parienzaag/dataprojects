## 3. Exploring the Data ##

import pandas as pd

avengers = pd.read_csv("avengers.csv")
avengers.head(5)

## 4. Filtering Out Bad Data ##

import matplotlib.pyplot as plt
true_avengers = pd.DataFrame()
true_avengers = avengers[avengers['Year'] > 1959]

avengers['Year'].hist()



## 5. Consolidating Deaths ##

def death_count(row):
    d = ['Death1','Death2','Death3','Death4','Death5']
    num_deaths = 0
    
    for c in d:
        death = row[c]
        if pd.isnull(death) or death == 'NO':
            continue
        elif death == 'YES':
            num_deaths += 1
    return num_deaths

true_avengers['Deaths'] = true_avengers.apply(death_count, axis = 1)

## 6. Verifying Years Since Joining ##

joined_accuracy_count  = int()
#calculating how many years said avenger has been an avenger using 2015 as reference Year
correct_joined_years =true_avengers[true_avengers['Years since joining'] == (2015 - true_avengers['Year'])]
#puting integer value to number of rows w correct value
joined_accuracy_count = len(correct_joined_years)