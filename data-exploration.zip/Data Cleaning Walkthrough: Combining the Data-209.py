## 3. Condensing the Class Size Data Set ##

#new varialble
class_size = data["class_size"]
#choosing only grades 9-12 on Grade coolemn
class_size = class_size[class_size["GRADE " ]== "09-12"]
#filtering data to include onlly GEN Ed fows
class_size = class_size[class_size["PROGRAM TYPE"]== "GEN ED"]
print(class_size.head(5))

## 5. Computing Average Class Sizes ##

import numpy
class_size= class_size.groupby("DBN").agg(numpy.mean)
#after groupby is used the DBN column loses its indexing
#resetting index of DBN column
class_size.reset_index(inplace = True)
data['class_size'] = class_size

print(data['class_size'].head())

## 7. Condensing the Demographics Data Set ##

demographics= data["demographics"]
#filtering out data[demographics] where schoolyear = 20112012
data["demographics"] = demographics[demographics["schoolyear"] == 20112012]
#the schoolyear is an int not a string
print(data["demographics"].head())

## 9. Condensing the Graduation Data Set ##

data['graduation'] = data['graduation'][data['graduation']['Cohort'] == "2006"]
#same filtering for Total cohort from Demographic column
data['graduation'] = data['graduation'][data['graduation']['Demographic'] == 'Total Cohort']

print(data['graduation'].head())

## 10. Converting AP Test Scores ##

cols = ['AP Test Takers ', 'Total Exams Taken', 'Number of Exams with scores 3 4 or 5']
#converting values to numeric
for col in cols:
    data['ap_2010'][col] = pd.to_numeric(data['ap_2010'][col], errors = "coerce")
#check datatypes to see if conversion happened
data['ap_2010'].dtypes


## 12. Performing the Left Joins ##


combined = data["sat_results"].merge(data["ap_2010"],how ="left",on = "DBN")
#merging graduation data set w left join
combined = combined.merge(data["graduation"],how = "left", on="DBN")

print(combined.head())
print(combined.shape)

## 13. Performing the Inner Joins ##

dflist = ["class_size", "demographics","survey","hs_directory"]

for name in dflist:
    combined = combined.merge(data[name],how = "inner", on="DBN")

print(combined.head())
print(combined.shape)

## 15. Filling in Missing Values ##

#calculating mean of all columns to fill null values
means = combined.mean()
#fill in null cells
combined = combined.fillna(means)
#fill in remaining null with 0
combined = combined.fillna(0)

print(combined.head(5))

## 16. Adding a School District Column for Mapping ##

#finished cleaning data now can perform analysis
def extract(string):
    return string[0:2]

#use the apply method to apply functions to the data set
combined["school_dist"] = combined["DBN"].apply(extract)
print(combined["school_dist"].head(5))